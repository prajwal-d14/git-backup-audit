#include <stdio.h>

// Function declarations
 int biggest();
 int factorial();
 int natural();
 
 int main() {
     biggest();
     factorial();
     natural();
     return 0;
     }                
