#!/bin/bash

sudo apt update
sudo apt install openjdk-17-jdk
java -version

